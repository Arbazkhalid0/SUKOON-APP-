# Sukoon
Islamic lifestyle app (no Quran/Hadith text). Run with a local server, e.g. VS Code "Live Server".
