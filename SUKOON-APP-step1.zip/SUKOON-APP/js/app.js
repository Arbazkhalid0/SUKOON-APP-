function hijriDate(d = new Date()) {
  return new Intl.DateTimeFormat('en-u-ca-islamic-umalqura', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
}
function greeting() {
  const h = new Date().getHours();
  return h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
}
Pages.home = () => {
  document.getElementById('hijri').textContent = hijriDate();
  document.getElementById('greet').textContent = greeting();
};
document.addEventListener('DOMContentLoaded', () => Nav.init());
