// Step 3: prayer times logic goes here
window.Prayer = {};
