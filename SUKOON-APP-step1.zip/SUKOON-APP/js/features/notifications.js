// Step 8: reminders and adhan notifications go here
window.Notify = {};
