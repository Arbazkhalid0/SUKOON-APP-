window.Pages = {};
const Nav = {
  routes: ['home','prayer','tasbeeh','daily-reflection','islamic-calendar','good-deeds','fasting','settings'],
  view: null,
  async go() {
    const name = location.hash.replace('#/','') || 'home';
    const route = this.routes.includes(name) ? name : 'home';
    this.view.scrollTop = 0;
    try {
      const res = await fetch('pages/' + route + '.html');
      if (!res.ok) throw new Error(res.status);
      this.view.innerHTML = await res.text();
    } catch {
      this.view.innerHTML = '<div class="empty card"><h2>Page unavailable</h2><p>Open the app through a local server (for example VS Code Live Server) instead of opening the file directly.</p></div>';
    }
    document.querySelectorAll('#tabbar a').forEach(a => a.classList.toggle('active', a.dataset.route === route));
    if (Pages[route]) Pages[route]();
  },
  init() {
    this.view = document.getElementById('view');
    window.addEventListener('hashchange', () => this.go());
    if (!location.hash) location.hash = '#/home';
    this.go();
  }
};
